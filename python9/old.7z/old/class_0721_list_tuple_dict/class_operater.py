#运算符
#算术运算符  +  -  *   /   %(取余)

#判断奇数偶数  %(取余运算)  取模

#赋值运算符  =  +=（重点）  -=
# += 计算和
# a=1
# b=3
# # a+=1#--->a=a+1
# # a+=2
# a-=4#a=a-4
# print(a)

#比较运算符 > 、 >= 、 < 、　<= 、 == 、 != 共6种
#运算结果是：布尔值 True  False
# a=1
# b=6
# print(a>b)
# print('get'=='GET')
# #字符串  字符串.upper()转成大写
# print('get'.upper()=='GET')
# #字符串  字符串.lower()转成小写
# print('get'=='GET'.lower())

#逻辑运算符  and or not
# a=5
# b=-5
# print(a>0 and b>0)
# print(a>0 or b>0)
#and 左右两边同事为真 才为真
#or 左右两边有一边为真就为真
#and 真真为真  or假假为假
#优先级 not>and>or  想要改变优先级，就可以用括号
# a=5
# b=-5
# print(a>0 and b<0 or a+b>10)
# print(a>0 and b<0 or a+b>=0)

#课后拓展not

#成员运算符  in  not in
#运算结果是：布尔值 True False
# s='hello'
# print('h'in s)

#常用控制流if&for&While(一)