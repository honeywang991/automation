__author__ = 'zz'
#%d %d %f
# s = '6'
# print("输出数据%d"%s)#这里会报错 要求是整数类型的数据

# s='aa'
# b='cc'
# print("msg is {0}{1}".format(s,b))