#coding=utf-8
# 作者:Administrator


for j in range(2, 4):  # 控制行
    for i in range(1, 6):  # 控制列
        print(j,i)

