class MathMethod: #数学类
    def add(self,a,b):#加法 第一个目标
        return (a+b)

    def sub(self,a,b):#减法
        return a-b




# if __name__ == '__main__':
#     pass