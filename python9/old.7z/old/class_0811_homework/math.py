
#被测函数
class math:#数学类
    def add(self,a,b):#类函数 类方法
        return (a+b) #return print

