#while循环
#while 条件表达式：
    #while代码块

age=18
count=0
while age>=18:
    print("我18岁了")
    count+=1
    if count==5:
        break
#while是先判断 后去执行代码块，执行完了之后，继续判读，根据判读结果执行
#反复判读
#bireak 跳出当前循环
#题目： 只打印5次，然后跳出循环
#怎么避免死循环
#1）用变量来控制，2）结合break和if语句来执行



