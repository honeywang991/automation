#coding=utf-8
# 作者:Administrator
import unittest
class TestAdd(unittest.TestCase):
    def test_add(self):
        a=1
        b=3
        print(a+b)

    def test_add_2(self):
        a=5
        b=5
        print(a+b)
