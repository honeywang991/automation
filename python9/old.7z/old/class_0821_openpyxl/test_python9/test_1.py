class Add:
    def test_add(self,a,b):
        return a+b